int	main()
{
	char *c = "Hello";
	printf("%d", ft_strlen(c));
}
