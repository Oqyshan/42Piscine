int	main()
{
	char *c = "Hello";
	ft_putstr(c);
}
